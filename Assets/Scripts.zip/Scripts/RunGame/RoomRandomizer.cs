using Photon.Pun;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Room
{
    public string name;
    public GameObject[] roomAssets;
    public float spawnChance;
    public int maxSpawn;
    public int minSpawn;
    [HideInInspector] public int roomCountMax;
    [HideInInspector] public int roomCountCurrent;
}

public class RoomRandomizer : MonoBehaviour
{
    [Header("RoomsCreate")]
    [SerializeField] Room[] roomsConfig;

    [Header("Collision Check")]
    [SerializeField] private LayerMask roomMask; // layer das salas

    List<Room> currentRooms = new List<Room>();
    List<GameObject> roomObj = new List<GameObject>();

    void Start()
    {
        if (PhotonNetwork.IsMasterClient)
        {
            SpawnRooms();
        }
    }

    void SpawnRooms()
    {
        // Define quantas vezes cada sala pode spawnar e sorteia se entra na lista
        foreach (Room room in roomsConfig)
        {
            room.roomCountMax = Random.Range(room.minSpawn, room.maxSpawn);
            if (Random.Range(0, room.spawnChance) <= 1)
            {
                currentRooms.Add(room);
            }
        }

        foreach (Room room in currentRooms)
        {
            for (int x = 0; x < room.roomCountMax; x++)
            {
                GameObject prefabRoom = room.roomAssets[Random.Range(0, room.roomAssets.Length)];
                BoxCollider prefabCollider = prefabRoom.GetComponent<BoxCollider>();
                Vector3 prefabSize = Vector3.Scale(prefabCollider.size, prefabRoom.transform.lossyScale);
                if (roomObj.Count == 0)
                {
                    // Spawn inicial
                    roomObj.Add(PhotonNetwork.Instantiate("NaveRooms/Rooms/" + prefabRoom.name, Vector3.zero, Quaternion.identity));
                    continue; // n�o sai do m�todo, s� pula pro pr�ximo loop
                }

                // Tenta expandir a partir de todas as salas j� spawnadas
                bool roomSpawned = false;
                while (!roomSpawned)
                {

                    GameObject obj = roomObj[Random.Range(0, roomObj.Count)];
                    BoxCollider roomCollider = obj.GetComponent<BoxCollider>();

                    int sideSpawn = Random.Range(0, 4);
                    Vector3 pos = Vector3.zero;
                    if(sideSpawn == 0) pos = obj.transform.position + Vector3.forward * obj.transform.lossyScale.z;
                    if(sideSpawn == 1) pos = obj.transform.position + Vector3.forward * obj.transform.lossyScale.z;
                    if(sideSpawn == 2) pos = obj.transform.position + Vector3.left * obj.transform.lossyScale.x;
                    if(sideSpawn == 3) pos = obj.transform.position + Vector3.right * obj.transform.lossyScale.x;

                    if (!Physics.CheckBox(pos, prefabSize/2, Quaternion.identity))
                    {
                        roomObj.Add(PhotonNetwork.Instantiate("NaveRooms/Rooms/" + prefabRoom.name, pos, Quaternion.identity));
                        roomSpawned = true;
                    }
                }


            }
        }

    }
}
