using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class LoadPlayer : MonoBehaviour
{
    private void Start()
    {
        PhotonNetwork.Instantiate(Path.Combine("Players", "Player"), transform.position, Quaternion.identity);
    }
}
