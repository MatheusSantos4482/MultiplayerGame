using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using TMPro;
using UnityEditor.UIElements;
using System;
using Photon.Realtime;

public class PlController : MonoBehaviourPunCallbacks
{
    private PlMovement plMove;

    [Header("Player Props")]
    [SerializeField] Renderer[] Baserender;
    [SerializeField] Renderer[] Secundaryrender;
    [SerializeField] TextMeshProUGUI nickNameText;

    void Start()
    {
        plMove = GetComponent<PlMovement>();


        // ATUALIZA AS CORES ============================================================
        foreach(Renderer rend in Baserender) // Cor Base
        {
            object color;
            photonView.Owner.CustomProperties.TryGetValue("Color1", out color);
            rend.material.SetColor("_Color", (Color)color);
        }
  
        foreach (Renderer rend in Secundaryrender) // Cor Base
        {
            object color;
            photonView.Owner.CustomProperties.TryGetValue("Color2", out color);
            rend.material.SetColor("_Color", (Color)color);
        }

        // ATUALIZA O NICKNAME DO PLAYER ================================================
        nickNameText.text = photonView.Owner.NickName;
    }
}
